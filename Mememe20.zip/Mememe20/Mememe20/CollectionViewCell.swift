//
//  CollectionViewCell.swift
//  Mememe20
//
//  Created by Jan Gundorf on 24/03/2019.
//  Copyright © 2019 Jan Gundorf. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
}
