//
//  MemeStruct.swift
//  PickingImages
//
//  Created by Jan Gundorf on 13/03/2019.
//  Copyright © 2019 Jan Gundorf. All rights reserved.
//

import Foundation
import UIKit

struct MemeStruct {
    var topText: String
    var buttomText: String
    var imageOriginal: UIImage
    var memedImage: UIImage
}
