//
//  ViewController.swift
//  Mememe20
//
//  Created by Jan Gundorf on 23/03/2019.
//  Copyright © 2019 Jan Gundorf. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
}

